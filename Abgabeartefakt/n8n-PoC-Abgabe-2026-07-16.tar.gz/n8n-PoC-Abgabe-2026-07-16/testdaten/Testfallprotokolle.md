# Testfallprotokolle SollProzess

Stand: 2026-07-09

## Vorgehen vor jedem Testlauf

- Alte wartende Executions abbrechen, damit keine alten Formularlinks weiterlaufen.
- Workflow eindeutig dem Testfall zuordnen oder vor dem Test duplizieren.
- In n8n unter `Executions` die Haupt-Execution-ID notieren.
- `debug_run_id`, Screenshots der relevanten KP-Seiten und erzeugte Protokolle sichern.
- Im Node `Stückliste laden` die passende Datei für den Testfall verwenden.
- KP1-CSV im Spaltenschema unverändert lassen. Nur Inhalte anpassen, keine Spalten löschen oder umbenennen.
- Für Tests in einer neuen Umgebung `N8N_FILES_DIR`, `N8N_RESTRICT_FILE_ACCESS_TO`, `WEBHOOK_URL`, SMTP-Credentials und Ollama-Credentials prüfen.

## TF1

Testfall:
TF1 - Standarddurchlauf mit drei Materialpositionen und vollständigem Ablauf bis AF15.

Eingabedatei:
[TF1/stueckliste_TF1.csv](TF1/stueckliste_TF1.csv), Stammdaten [lieferanten.csv](lieferanten.csv), erzeugte KP1-CSV [TF1/kp1_20260709123333_imq9c0_mo0o1isii2c.csv](TF1/kp1_20260709123333_imq9c0_mo0o1isii2c.csv).

Ziel:
Prüfen, ob drei Positionen eingelesen, Lieferanten korrekt zugeordnet, Lieferantenantworten verarbeitet, ein Kostenvoranschlag erzeugt, Bestellmails vorbereitet und Auftragsbestätigungen in AF15 nachvollziehbar bewertet werden.

Erwartetes Ergebnis:
Alle drei Positionen werden in KP1 mit `status = ok` verarbeitet. KP1b, AF7, KP2, KP3 und KP4 können freigegeben werden. AF15 soll korrekte Auftragsbestätigungen erkennen beziehungsweise Abweichungen nachvollziehbar ausweisen und eine dokumentierte Entscheidung der verantwortlichen Person ermöglichen.

Tatsächliches Ergebnis:
Der Durchlauf wurde abgeschlossen. In AF7 war die KI-Extraktion erforderlich, weil für Position 3 offene beziehungsweise abweichende Angebotsdaten erkannt wurden. AF7d übernahm 6 Angebotszeilen für 3 Positionen. In KP2 wurden als beste Angebote gewählt: Pos. 1 `Stahlhandel-Nord` mit 321,22 EUR, Pos. 2 `Inox-Fachhandel` mit 1.306,00 EUR, Pos. 3 `Stahlhandel-Nord` mit 256,98 EUR. KP3 berechnete 1.884,20 EUR Beschaffungskosten und 2.449,46 EUR Kostenvoranschlag bei Faktor 1,3. AF15 bewertete `Stahlhandel-Nord` als korrekt und `Inox-Fachhandel` als abweichend. Die Abweichung wurde durch Entscheidung der verantwortlichen Person akzeptiert. Finaler Workflow-Status: `korrekt`.

Execution-ID:
`398`

Debug-Run-ID:
`run_2026-07-09T12-34-57-707Z_ch33xo`

Screenshots:
[KP1](TF1/KP1-%20CSV%20Einlesen%20Kontrolle.png), [KP1b](TF1/KP1b-%20Anfrage-Mails%20pr%C3%BCfen.png), [AF7](TF1/AF7-Lieferantenantworten%20erfassen.png), [KP2](TF1/KP2-%20Bestellzuordnung.png), [KP3](TF1/KP3-%20Kostenvoranschlag%20freigeben.png), [KP4](TF1/KP4-%20Bestellmails%20pr%C3%BCfen.png), [AF15](TF1/AF15-%20Auftragsbest%C3%A4tigung.png).

Abweichungen:
AF15 meldete vor der Entscheidung der verantwortlichen Person `nicht korrekt`, weil bei `Inox-Fachhandel` eine zusätzliche Position in der Auftragsbestätigung und eine fehlende Position gegenüber der Bestellung erkannt wurde. Im Ablauf wurden 9 Warnungen und 0 Fehler protokolliert.

Korrektur / Retest:
Kein technischer Workflow-Fehler. Für einen Retest mit komplett korrektem Ende muss eine fachlich eindeutige Auftragsbestätigung ohne Zusatz-/Fehlpositionen verwendet werden. Dann sollte der Prozess direkt Richtung `AF16 - Auf Lieferung warten` laufen.

Durchlaufprotokoll:
[TF1/SollProzess_Protokoll_run_2026-07-09T12-34-57-707Z_ch33xo.md](TF1/SollProzess_Protokoll_run_2026-07-09T12-34-57-707Z_ch33xo.md)

## TF2

Testfall:
TF2 - Fehlende Norm in einer Stücklistenposition.

Eingabedatei:
[TF2/stueckliste_TF2.csv](TF2/stueckliste_TF2.csv), erzeugte KP1-CSV [TF2/kp1_20260709130459_uvysgo_di9e3juvi7a.csv](TF2/kp1_20260709130459_uvysgo_di9e3juvi7a.csv).

Ziel:
Prüfen, ob eine fehlende Norm erkannt wird und nicht unbemerkt in die automatische Weiterverarbeitung läuft.

Erwartetes Ergebnis:
Position 1 wird normal verarbeitet. Position 2 enthält keine Norm und muss in KP1 als `offen/prüfpflichtig` erscheinen. Der Workflow darf ohne menschliche Entscheidung nicht weiterlaufen. Bei Ablehnung mit Aktion `abbrechen` muss ein Abbruchprotokoll erzeugt werden.

Tatsächliches Ergebnis:
KP1 erzeugte für Position 1 den Status `ok`. Position 2 (`Rohr 60.3x3.2`, `1.4301 EDELSTAHL`, Norm leer) wurde in der KP1-CSV zweimal mit Lieferantenzuordnung, aber mit Status `offen/prüfpflichtig` ausgegeben. Die fehlende Norm wurde damit an KP1 erkannt; der Test wurde dort manuell mit `ablehnen` und der Aktion `abbrechen` beendet. Abbruchgrund: `Test: Position 2 hat keine Norm (EN/DIN)`.

Execution-ID:
`401`

Debug-Run-ID:
Nicht im Abbruchprotokoll enthalten.

Screenshots:
[KP1](TF2/KP1-%20CSV%20Einlesen%20Kontrolle.png).

Abweichungen:
Keine technische Abweichung. Das erwartete Prüfverhalten wurde erreicht und der Test nach der Erkennung manuell abgebrochen. Das Abbruchprotokoll enthält keinen `debug_trace`, dokumentiert aber Entscheidung, Abbruchstelle und Abbruchgrund.

Abbruchprotokoll:
[TF2/SollProzess_Abbruchprotokoll_2026-07-09T13-06-30-276Z.md](TF2/SollProzess_Abbruchprotokoll_2026-07-09T13-06-30-276Z.md)

## TF3

Testfall:
TF3 - Kein passender Lieferant für Titanposition.

Eingabedatei:
[TF3/stueckliste_TF3.csv](TF3/stueckliste_TF3.csv), erzeugte KP1-CSV [TF3/kp1_20260709130742_ni39lg_hvr0l4hzej.csv](TF3/kp1_20260709130742_ni39lg_hvr0l4hzej.csv).

Ziel:
Prüfen, ob eine Titanposition nicht falsch einem ungeeigneten Lieferanten zugeordnet wird.

Erwartetes Ergebnis:
Die Position wird eingelesen, aber nicht automatisch einem Lieferanten zugeordnet. In KP1 muss `status = offen/prüfpflichtig` und eine fehlende Lieferantenzuordnung sichtbar sein. Der Test soll mit `ablehnen` und `abbrechen` sauber dokumentiert enden.

Tatsächliches Ergebnis:
Die Position `Titanrohr 20x2`, Menge 3, Werkstoff `TITAN GRADE 2`, Norm `ASTM B338` wurde eingelesen. Die KP1-CSV enthält keinen Lieferanten, keine Sortimentsbreite und Kosten `0.00`. Status: `offen/prüfpflichtig`. Die fehlende Zuordnung wurde damit an KP1 erkannt; der Test wurde dort manuell mit `ablehnen` und der Aktion `abbrechen` beendet. Abbruchgrund: `Kein passender Lieferant`.

Execution-ID:
`404`

Debug-Run-ID:
Nicht im Abbruchprotokoll enthalten.

Screenshots:
[KP1](TF3/KP1-%20CSV%20Einlesen%20Kontrolle.png).

Abweichungen:
Keine technische Abweichung. Der Workflow hat die kritische Position nicht automatisch falsch zugeordnet.

Abbruchprotokoll:
[TF3/SollProzess_Abbruchprotokoll_2026-07-09T13-08-51-388Z.md](TF3/SollProzess_Abbruchprotokoll_2026-07-09T13-08-51-388Z.md)

## TF4

Testfall:
TF4 - Zusatzkostenvergleich bei gleichem Stückpreis.

Eingabedatei:
[TF4/stueckliste_TF4.csv](TF4/stueckliste_TF4.csv), erzeugte KP1-CSV [TF4/kp1_20260709142502_3b0sm6_b9q3z59mrd.csv](TF4/kp1_20260709142502_3b0sm6_b9q3z59mrd.csv).

Ziel:
Prüfen, ob bei gleichem Stückpreis die Neben-/Entladungskosten korrekt in die Lieferantenauswahl einbezogen werden.

Erwartetes Ergebnis:
Für `Flachstahl 60x8`, Menge 20, werden `Stahl-Meier GmbH` und `Stahlhandel-Nord` verglichen. Beide Angebote haben 10,00 EUR Stückpreis. Wegen geringerer Neben-/Entladungskosten muss `Stahlhandel-Nord` gewählt werden. Erwartete Rechnung: `20 * 10 + 20 + 10 = 230,00 EUR`. KP3 muss bei Faktor 1,3 einen Kostenvoranschlag von 299,00 EUR erzeugen. Die KI in AF7 darf übersprungen werden, wenn das strukturierte Angebots-JSON vollständig ist.

Tatsächliches Ergebnis:
AF7 verarbeitete 2 Antwortmails und 4 Fallback-Angebotszeilen. `ki_noetig = false`. Der Workflow lief über `AF7c2 - KI überspringen und Fallback nutzen`. AF7d übernahm 4 verwertbare Angebotszeilen ohne fehlende Positionen. KP2/KP3 wählten `Stahlhandel-Nord`, Stückpreis 10,00 EUR, kalkulierter Anteil 230,00 EUR. KP3 berechnete 230,00 EUR Beschaffungskosten und 299,00 EUR Kostenvoranschlag. KP4 erzeugte eine Bestellmail mit Bestellwert 230,00 EUR. AF15 bewertete die Auftragsbestätigung als `unklar`, weil Positionsdetails und Preise nicht ausdrücklich genug bestätigt wurden. Die Entscheidung der verantwortlichen Person war `Abweichung akzeptieren - fortsetzen`. Finaler Workflow-Status: `korrekt`.

Execution-ID:
`416`

Debug-Run-ID:
`run_2026-07-09T14-25-48-427Z_niodb7`

Screenshots:
[KP1](TF4/KP1-%20CSV%20Einlesen%20Kontrolle.png), [KP1b](TF4/KP1b%20Anfrage%20Mails%20pr%C3%BCfen.png), [AF7](TF4/AF7%20Lieferantenantworten%20erfassen.png), [KP2](TF4/KP2%20bestellzuordnung%20best%C3%A4tigen.png), [KP3](TF4/KP3-Kostenvoranschlag%20freigaben.png), [KP4](TF4/KP4-%20Bestellmails%20pr%C3%BCfen.png), [AF15 Ergebnis](TF4/AF15-%20Auftragsbest%C3%A4tigung.png), [AF15 Hinweis](TF4/AF15-%20Auftragsbest%C3%A4tigung%28als%20falsch%20deklariert%2C%20aber%20alle%20richtig%29.png).

Abweichungen:
Die Kernprüfung des Zusatzkostenvergleichs wurde bestanden. AF15 war für diesen Testfall nicht der fachliche Schwerpunkt und meldete `unklar`, weil die Auftragsbestätigung nicht genug Positionsdetails enthielt. Im Ablauf wurden 3 Warnungen und 0 Fehler protokolliert.

Durchlaufprotokoll:
[TF4/SollProzess_Protokoll_run_2026-07-09T14-25-48-427Z_niodb7.md](TF4/SollProzess_Protokoll_run_2026-07-09T14-25-48-427Z_niodb7.md)

## TF5

Testfall:
TF5 - Auftragsbestätigung mit absichtlicher Abweichung.

Eingabedatei:
[TF5/stueckliste_TF5.csv](TF5/stueckliste_TF5.csv), erzeugte KP1-CSV [TF5/kp1_20260709144225_bdbor5_8dd3ptyhvi9.csv](TF5/kp1_20260709144225_bdbor5_8dd3ptyhvi9.csv).

Ziel:
Prüfen, ob eine abweichende oder unvollständige Auftragsbestätigung nicht direkt als korrekt akzeptiert wird und der Workflow eine Klärungsentscheidung ermöglicht.

Erwartetes Ergebnis:
Die Position `Rohr 88.9x4`, Menge 6, Werkstoff `1.4571 Edelstahl`, Norm `EN 10217-7`, wird normal verarbeitet. Bei einer absichtlich problematischen Auftragsbestätigung mit Menge 7 und Positionspreis 420,00 EUR darf AF15 die Bestätigung nicht automatisch als korrekt akzeptieren. Erwartet wird eine Klärentscheidung. Eine eindeutige technische Klassifikation als `abweichend` wäre nur bei belastbar extrahierten Positionsdaten zu erwarten. Die Entscheidung der verantwortlichen Person `Nicht korrekt / Klärung erforderlich` soll final als `nicht korrekt` protokolliert werden.

Tatsächliches Ergebnis:
KP1 ordnete die Position `Edelstahl-Mueller` und `Inox-Fachhandel` mit Status `ok` zu. AF7 verarbeitete 2 Antwortmails und 2 Fallback-Angebotszeilen. `ki_noetig = false`. Die KI wurde übersprungen und Fallback-Angebote wurden verwendet. KP2/KP3 wählten `Inox-Fachhandel`, Stückpreis 742,00 EUR, kalkulierter Anteil 4.695,00 EUR. KP3 berechnete 4.695,00 EUR Beschaffungskosten und 6.103,50 EUR Kostenvoranschlag. AF15 bewertete die Auftragsbestätigung als `unklar` mit Datenvollständigkeit 0 %, weil Menge und Preis nicht belastbar bestätigt wurden. Die Entscheidung der verantwortlichen Person war `Nicht korrekt / Klärung erforderlich`. Finaler Workflow-Status: `nicht korrekt`. Kommentar/Korrektur dokumentierte die absichtlich falsche AB mit Menge 7, Positionspreis 420,00 EUR und Lieferzeit 5 Werktage.

Execution-ID:
`419`

Debug-Run-ID:
`run_2026-07-09T14-50-53-756Z_puhz0g`

Screenshots:
[KP1](TF5/KP1-%20CSV%20Einlesen%20Kontrolle.png), [KP1b](TF5/KP1b-%20Anfrage-Mails%20pr%C3%BCfen.png), [AF7](TF5/AF7-%20Lieferantenantworten%20erfassen.png), [KP2](TF5/KP2-%20Bestellzuordnung%20best%C3%A4tigen.png), [KP3](TF5/KP3-%20Kostenvoranschlag%20freigeben.png), [KP4](TF5/KP4-%20Bestellmails%20pr%C3%BCfen.png), [Kundenantwort](TF5/Kundenantwort%20erfassen.png), [AF15 Ergebnis](TF5/AF15-%20Auftragsbest%C3%A4tigung%3A%20Ergebnis.png).

Abweichungen:
AF15 klassifizierte die Auftragsbestätigung als `unklar`, weil Menge und Preis nicht belastbar bestätigt wurden. Der Workflow akzeptierte die Auftragsbestätigung nicht automatisch als korrekt. Die Entscheidung der verantwortlichen Person `Nicht korrekt / Klärung erforderlich` führte zum finalen Status `nicht korrekt`. Im Ablauf wurden 3 Warnungen und 0 Fehler protokolliert.

Durchlaufprotokoll:
[TF5/SollProzess_Protokoll_run_2026-07-09T14-50-53-756Z_puhz0g.md](TF5/SollProzess_Protokoll_run_2026-07-09T14-50-53-756Z_puhz0g.md)
